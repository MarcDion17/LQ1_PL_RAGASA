#Create variable that will store the Names of your groupmate
member_one = "Angelbert James F. Ablan"
member_two = "Christian D. Rupisan"
member_three = "Marc Dion G. Ragasa"

#Create Variable that contains age of groupmates
age_member_one= "21"
age_member_two = "20"
age_member_three = "20"

age_one = int(age_member_one)
age_two = int(age_member_two)
age_three = int(age_member_three)

#Create Variable that contains weekly allowance of groupmates
member_one allowance = float(800.0)
member_two allowance = float(500.0)
member_three allowance = float(500.0)

print("Member 1:" + member_one + "," + "his age is" + age_one+ "," + "allowance per week is" + memberAllowance1)
print("Member 2:" + member_two + "," + "his age is" + age_two + "," + "allowance per week is" + memberAllowance2)
print("Member 3:" + member_three + "," + "his age is" + age_three + "," + "allowance per week is" + memberAllowance3)

#Create variable that store length of the members

member_oneNameLength = len(member_one)
member_twoNameLength = len(member_two)
member_threeNameLength = len(member_three)

print ("Member 1 consists of" + member_oneNameLength + "characters")
print ("Member 2 consists of" + member_twoNameLength + "characters")
print ("Member 3 consists of" + member_threeNameLength + "characters")

#add age
sumMember = (age_member_one + age_member_two + age_member_three)
print (sumMember)

#subtract age
subMember = (ge_member_one + age_member_two + age_member_three)
print (subMember)
 
 #multiply age and allowance
product1 = (age_member_one * member_one allowance)
product2 = (age_member_two * member_two allowance)
product3 = (age_member_three * member_three allowance)

print (product1)
print (product2)
print (product3)

#compare age
compare1 = (age_member_one - age_member_two)
compare2 = (age_member_two - age_member_three)

print (compare1)
print (compare2)

#compare each name length
NameLength = (member_oneNameLength - member_twoNameLength)
NameLength2 = (member_twoNameLength - member_threeNameLength)
print (NameLength1)
print(NameLength2)