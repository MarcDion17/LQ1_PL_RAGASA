#Create variable that will store the Names of your groupmate
member_one = "Angelbert James F. Ablan"
member_two = "Christian D. Rupisan"
member_three = "Marc Dion G. Ragasa"

#Create Variable that contains age of groupmates
age_member_one= "21"
age_member_two = "20"
age_member_three = "20"

age_one = int(age_member_one)
age_two = int(age_member_two)
age_three = int(age_member_three)

#Create Variable that contains weekly allowance of groupmates
member_one allowance = float(800.0)
member_two allowance = float(500.0)
member_three allowance = float(500.0)

print("Member 1:" + memberName1 + "," + "his age is" + memberAge1 + "," + "allowance per week is" + memberAllowance1)
print("Member 2:" + memberName2 + "," + "his age is" + memberAge2 + "," + "allowance per week is" + memberAllowance2)
print("Member 3:" + memberName3 + "," + "his age is" + memberAge3 + "," + "allowance per week is" + memberAllowance3)

#Create variable that store length of the members

member_1NameLength = len(memberName1)
member_2NameLength = len(memberName2)
member_3NameLength = len(memberName3)

print ("Member 1 consists of" + member_1NameLength + "characters")
print ("Member 2 consists of" + member_2NameLength + "characters")
print ("Member 3 consists of" + member_3NameLength + "characters")
